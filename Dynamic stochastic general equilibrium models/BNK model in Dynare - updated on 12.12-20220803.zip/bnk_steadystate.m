% computes the steady state of bnk analytically
% largely inspired by the program of F. Schorfheide
%% parameters values are taken from the main file with model called bnk.dyn
function [ys,check] = bnk_steadystate(ys,exe)
  global M_
  global oo_
  
  alfa =      M_.params(1); 
  bet =       M_.params(2);
  epsi =      M_.params(3);
  phi =       M_.params(4);
  phipi =     M_.params(5);
  phigap =    M_.params(6);
  rhoa =      M_.params(7);
  rhov =      M_.params(8);
  gam =       M_.params(9);
  theta =     M_.params(10);
  eta =       M_.params(11);
  
  epsv =      oo_.exo_steady_state(1);        
  epsa =      oo_.exo_steady_state(2); 
  

 
  check = 0;

%--------------------------------------------------------------------------%  
%% parameters' transformations
theta_big=(1-alfa)/(1-alfa+alfa*epsi);
lam=(1-theta)*(1-bet*theta)/theta*theta_big;
kap=lam*(gam+(phi+alfa)/(1-alfa));
ksi=(1+phi)/(gam*(1-alfa)+phi+alfa);
mi=log(epsi/(epsi-1));
wal=-(1-alfa)*(mi-log(1-alfa))/(gam*(1-alfa)+phi+alfa);
rho=-log(bet);
%--------------------------------------------------------------------------% 
%%
v=0;
a=0;
rn=0;
gap=0;
pi=0;
i=rho;
yn=wal;
y=yn;
n=y/(1-alfa);
M=0;
pia=pi*4;
ia=i*4;
ra=ia-pia;
MA=M*4;
%--------------------------------------------------------------------------%  
%%
%declare in exactly the same order as in the 'var' command in the main file 

  ys =[
pi
gap
y
yn
i
rn
M
n
v
a
pia
ia
ra
MA];