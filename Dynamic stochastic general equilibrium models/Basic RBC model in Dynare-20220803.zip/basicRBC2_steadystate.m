% computes the steady state of basicRBC analytically
% largely inspired by the program of F. Schorfheide
%% parameters values are taken from the main file with model called basicRBC.dyn
function [ys,check] = basicRBC2_steadystate(ys,exe)
  global M_
  global oo_
  
  gam =        M_.params(1); 
  phi =        M_.params(2);
  bet =        M_.params(3);
  delta =      M_.params(4);
  alfa =       M_.params(5);
  rhoa =       M_.params(6);
  A_steady =   M_.params(7);
  
  epsa =      oo_.exo_steady_state(1); 
  
  check = 0;

%--------------------------------------------------------------------------%  
%% parameters' transformations - when we want to write some functions of parameters shorter (not needed in this code)
%--------------------------------------------------------------------------% 
%%
A=A_steady;
r=1/bet-(1-delta);
w=(1-alfa)*(alfa/r)^(alfa/(1-alfa));
y=(r/(r-delta*alfa))^(gam/(gam+phi))*(w*(w/(1-alfa))^phi)^(1/(gam+phi));
i=delta*alfa/r*y;
c=y^(-phi/gam)*((1-alfa)^(-phi)*w^(1+phi))^(1/gam);
k=alfa/r*y;
l=(1-alfa)*y/w;
%--------------------------------------------------------------------------%  
%%
%declare in exactly the same order as in the 'var' command in the main file 

  ys =[
c
l
w
r
i
k
y
A];